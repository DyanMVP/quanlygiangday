<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function get_list_teacher(){
	global $wpdb;
    $table_name = $wpdb->prefix . 'teacher'; // Replace 'your_custom_table' with your table name
    $query = "SELECT * FROM $table_name";

    $results = $wpdb->get_results($query, ARRAY_A);

    return $results;
}

function get_data_by_id($id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'your_custom_table'; // Replace 'your_custom_table' with your table name

    $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id);
    $result = $wpdb->get_row($query, ARRAY_A);

    return $result;
}

//add data
function insert_data_action() {
    check_ajax_referer('custom-ajax-nonce', 'nonce');

    if (isset($_POST['teacher_id'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'teacher';

        $data = array(
            'teacher_id' => $_POST['teacher_id'],
            'full_name' => $_POST['full_name'],
            'date_of_birth' => $_POST['date_of_birth'],
            'sex' => $_POST['sex'],
            'address' => $_POST['address'],
            'phone' => $_POST['phone'],
            'position' => $_POST['position'],
            'ma_to_mon' => $_POST['ma_to_mon'],
        );

        $format = array(
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
        );

        $wpdb->insert($table_name, $data, $format);
        echo 'Data inserted successfully.';
    }

    wp_die();
}

add_action('wp_ajax_insert_data_action', 'insert_data_action');
add_action('wp_ajax_nopriv_insert_data_action', 'insert_data_action');

//edit data
function edit_data_action() {
    check_ajax_referer('custom-ajax-nonce', 'nonce');

    if (isset($_POST['id'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'teacher'; // Replace 'your_custom_table' with your table name

        $id = intval($_POST['id']); // Ensure the ID is an integer

        // Define the data to update
        $data = array(
            'teacher_id' => sanitize_text_field($_POST['teacher_id']),
            'full_name' => sanitize_text_field($_POST['full_name']),
            'date_of_birth' => sanitize_text_field($_POST['date_of_birth']),
            'sex' => sanitize_text_field($_POST['sex']),
            'address' => sanitize_text_field($_POST['address']),
            'phone' => sanitize_text_field($_POST['phone']),
            'position' => sanitize_text_field($_POST['position']),
            'ma_to_mon' => intval($_POST['ma_to_mon']), // Assuming this is an integer
        );

        $where = array('id' => $id);

        $wpdb->update($table_name, $data, $where);

        echo 'Data updated successfully.';
    }

    wp_die();
}

add_action('wp_ajax_edit_data_action', 'edit_data_action');
add_action('wp_ajax_nopriv_edit_data_action', 'edit_data_action');


//delete data
function delete_data_action() {
    check_ajax_referer('custom-ajax-nonce', 'nonce');

    if (isset($_POST['id'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'teacher'; // Replace 'your_custom_table' with your table name

        $id = intval($_POST['id']); // Ensure the ID is an integer

        $where = array('id' => $id);

        $wpdb->delete($table_name, $where);

        echo 'Data deleted successfully.';
    }

    wp_die();
}

add_action('wp_ajax_delete_data_action', 'delete_data_action');
add_action('wp_ajax_nopriv_delete_data_action', 'delete_data_action');