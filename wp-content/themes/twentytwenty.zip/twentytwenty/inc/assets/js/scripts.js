jQuery(document).ready(function ($) {
    "use strict";
    var dataId = 0;
    $('#addViewModal').each(function(){
        var element = $(this);
        element.find('.add_new_teacher').on('click', function(e){
            e.preventDefault();
            var fullName = element.find('input.full_name').val();
            var date = element.find('input.date').val();
            var radios = element.find('input[name="optradio"]');
            let sex = 'Nam';
            radios.each(function(){
                var radio = $(this);
                if (radio.is(':checked')){
                    sex = radio.attr('sex');
                }
            })
            var address = element.find('textarea.address').val();
            var phone = element.find('input.phone').val();
            var position = element.find('input.position').val();
            var maToMon = element.find('#select_to_mon').find(":selected").attr('value');

            if(fullName.trim() === '' || !date || address.trim() === '' || phone.trim() === '' || position.trim() === ''){
                console.log('validate error');
                return;
            }
            
            var data = {
                action: 'insert_data_action',
                teacher_id: 100,
                full_name: fullName,
                date_of_birth: date,
                sex: sex,
                address: address,
                phone: phone,
                position: position,
                ma_to_mon: maToMon,
                nonce: custom_ajax.nonce,
            };
            $.post(custom_ajax.ajax_url, data, function(response) {
                alert('Thêm mới thành công!');
                setTimeout(()=>{
                    window.location.reload();
                }, 500);
            });
        });

        element.find('.add_new_to_mon').on('click', function(e){
            e.preventDefault();
            var name = element.find('input.full_name').val();
            var number_teacher = element.find('input.so_giang_vien').val();
            if(name.trim() === '' || number_teacher.trim() === ''){
                console.log('validate error');
                alert('Vui lòng không để trống!');
                return;
            }
            var data = {
                action: 'insert_data_action_to_mon',
                ten_to_mon: name,
                so_giang_vien: number_teacher,
                ma_khoa: 'CNTT',
                nonce: custom_ajax.nonce,
            };
            $.post(custom_ajax.ajax_url, data, function(response) {
                alert('Thêm mới thành công!');
                setTimeout(()=>{
                    window.location.reload();
                }, 500);
            });
        })
    });

    $('#editViewModal').each(function(){
        var element = $(this);
        element.find('.edit_teacher').on('click', function(e){
            e.preventDefault();
            var fullName = element.find('input.full_name').val();
            var date = element.find('input.date').val();
            var radios = element.find('input[name="optradio"]');
            let sex = 'Nam';
            radios.each(function(){
                var radio = $(this);
                if (radio.is(':checked')){
                    sex = radio.attr('sex');
                }
            })
            var address = element.find('textarea.address').val();
            var phone = element.find('input.phone').val();
            var position = element.find('input.position').val();
            var maToMon = element.find('#select_to_mon').find(":selected").attr('value');

            if(fullName.trim() === '' || !date || address.trim() === '' || phone.trim() === '' || position.trim() === ''){
                console.log('validate error');
                return;
            }
            
            var data = {
                action: 'edit_data_action',
                id: dataId,
                teacher_id: 100,
                full_name: fullName,
                date_of_birth: date,
                sex: sex,
                address: address,
                phone: phone,
                position: position,
                ma_to_mon: maToMon,
                nonce: custom_ajax.nonce,
            };
            console.log('data==', data);
            $.post(custom_ajax.ajax_url, data, function(response) {
                alert('Chỉnh sửa thành công!');
                setTimeout(()=>{
                    window.location.reload();
                }, 500);
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log('AJAX Error:', errorThrown);
            });
        })

    });

    //append data form edit

    $('.table-responsive .edit').on('click', function(){
        dataId = $(this).attr('data-id');
        var row = $(this).parent().parent();
        var formEdit = $('#editViewModal');
        console.log('vào đây', row, formEdit.find('input.full_name'), row.find('td:first-child'));
        formEdit.find('input.full_name').val(row.find('td:nth-child(2)').text());
        var currentDate = row.find('td:nth-child(3)').attr('data-date');
        var dateValue = new Date(currentDate.split(' ')[0]);
        // Format the date as YYYY-MM-DD (date only)
        var formattedDate = dateValue.toISOString().split('T')[0];
        formEdit.find('input.date').val(formattedDate);
        var currentSex = row.find('td:nth-child(4)').text();
        if(currentSex === 'Nam'){
            formEdit.find('[sex="Name"]').prop('checked', true);
        } else{
            formEdit.find('[sex="Nữ"]').prop('checked', true);
        }
        
        formEdit.find('textarea.address').val(row.find('td:nth-child(5)').text());
        formEdit.find('input.phone').val(row.find('td:nth-child(6)').text());
        formEdit.find('input.position').val(row.find('td:nth-child(7)').text());
    });


    //remove teacher
    $('.table-responsive .delete').on('click', function(){
        dataId = $(this).attr('data-id');
    });

    $('#deleteViewModal').each(function(){
        var element = $(this);
        element.find('.delete_teacher').on('click', function(e){
            e.preventDefault();
            var data = {
                action: 'delete_data_action',
                id: dataId,
                nonce: custom_ajax.nonce,
            };
            console.log('data==', data);
            $.post(custom_ajax.ajax_url, data, function(response) {
                alert('Xóa thành công!');
                setTimeout(()=>{
                    window.location.reload();
                }, 500);
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log('AJAX Error:', errorThrown);
            });
        })

    });

});