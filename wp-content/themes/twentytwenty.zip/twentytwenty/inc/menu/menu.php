<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<?php
add_action('admin_menu', 'init_admin_main_menu', 10);

function callback_view()
{
    require_once THEME_LIB . '/view/teacher/teacher.php';
}

function teacher_view()
{
    require_once THEME_LIB . '/view/teacher/teacher.php';
}

function group_view()
{
    require_once THEME_LIB . '/view/to_mon/to_mon.php';
}

function init_admin_main_menu()
{
    $menuSlug = 'dan_admin_menu';
    //create new top-level menu
    add_menu_page(
        'Quản lý chung',
        'Quản lý chung',
        'administrator',
        $menuSlug,
        'callback_view',
        'dashicons-admin-settings',
        '40'
    );

    add_submenu_page(
        $menuSlug,
        'Teacher',
        'Teacher',
        'manage_options',
        'teacher.php',
        'teacher_view',
        '1'
    );

    add_submenu_page(
        $menuSlug,
        'Tổ môn',
        'Tô môn',
        'manage_options',
        'group.php',
        'group_view',
        '2'
    );
}