<div class="container-xl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h2>Quản lí <b>Giảng viên</b></h2>
                    </div>
                    <div class="col-sm-6">
                        <a href="#addViewModal" class="btn btn-success" data-toggle="modal"><i
                                class="material-icons">&#xE147;</i> <span>Thêm mới</span></a>
                        <!-- <a href="#deleteViewModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>						 -->
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Họ và tên</th>
                        <th>Ngày sinh</th>s
                        <th>Giới tính</th>
                        <th>Địa chỉ</th>
                        <th>Số điện thoại</th>
                        <th>Chức danh</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $data = get_list_teacher();
                    foreach ($data as $key => $row) {
                        echo '<tr>';
                        echo '<td>' . ($key + 1) . '</td>';
                        echo '<td>' . $row['full_name'] . '</td>';
                        echo '<td data-date="' . $row['date_of_birth'] . '">' . date("d/m/Y", strtotime($row['date_of_birth'])) . '</td>';
                        echo '<td>' . $row['sex'] . '</td>';
                        echo '<td>' . $row['address'] . '</td>';
                        echo '<td>' . $row['phone'] . '</td>';
                        echo '<td>' . $row['position'] . '</td>';
                        echo '<td>
                        <a href="#editViewModal" data-id="' . $row['id'] . '" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
                        <a href="#deleteViewModal" data-id="' . $row['id'] . '" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
                        </td>';
                        echo '</tr>';
                    }
                    ?>


                </tbody>
            </table>
            <div class="clearfix">
                <div class="hint-text">Showing <b>5</b> out of <b>25</b> entries</div>
                <ul class="pagination">
                    <li class="page-item disabled"><a href="#">Previous</a></li>
                    <li class="page-item"><a href="#" class="page-link">1</a></li>
                    <li class="page-item"><a href="#" class="page-link">2</a></li>
                    <li class="page-item active"><a href="#" class="page-link">3</a></li>
                    <li class="page-item"><a href="#" class="page-link">4</a></li>
                    <li class="page-item"><a href="#" class="page-link">5</a></li>
                    <li class="page-item"><a href="#" class="page-link">Next</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Edit Modal HTML -->
<div id="addViewModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form>
                <div class="modal-header">
                    <h4 class="modal-title">Thêm mới giảng viên</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Họ và tên</label>
                        <input type="text" class="form-control full_name" required>
                    </div>
                    <div class="form-group">
                        <label>Ngày sinh</label>
                        <input type="date" class="form-control date" required>
                    </div>
                    <div class="form-group">
                        <label>Giới tính</label>
                        <div class="form-check">
                            <label class="form-check-label">
                                <span>Nam</span><input type="radio" class="form-check-input" sex="Nam" checked
                                    name="optradio">
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label">
                                <span>Nữ</span><input type="radio" class="form-check-input" sex="Nữ" name="optradio">
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ</label>
                        <textarea class="form-control address" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" class="form-control phone" required>
                    </div>
                    <div class="form-group">
                        <label>Chức vụ</label>
                        <input type="text" class="form-control position" required>
                    </div>
                    <div class="form-group">
                        <label for="sel1">Lựa chọn tổ môn</label>
                        <select class="form-control" id="select_to_mon">
                            <?php
                            $data = get_list_to_mon();
                            foreach ($data as $row)
                                echo '<option value="' . $row['id'] . '">' . $row['ten_to_mon'] . '</option>'
                                    ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Hủy bỏ">
                        <input type="submit" class="btn btn-success add_new_teacher" value="Thêm mới">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Edit Modal HTML -->
    <div id="editViewModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h4 class="modal-title">Chỉnh sửa thông tin</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Họ và tên</label>
                            <input type="text" class="form-control full_name" required>
                        </div>
                        <div class="form-group">
                            <label>Ngày sinh</label>
                            <input type="date" class="form-control date" required>
                        </div>
                        <div class="form-group">
                            <label>Giới tính</label>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <span>Nam</span><input type="radio" class="form-check-input" sex="Nam" checked
                                        name="optradio">
                                </label>
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <span>Nữ</span><input type="radio" class="form-check-input" sex="Nữ" name="optradio">
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Địa chỉ</label>
                            <textarea class="form-control address" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Số điện thoại</label>
                            <input type="text" class="form-control phone" required>
                        </div>
                        <div class="form-group">
                            <label>Chức vụ</label>
                            <input type="text" class="form-control position" required>
                        </div>
                        <div class="form-group">
                            <label for="sel1">Lựa chọn tổ môn</label>
                            <select class="form-control" id="select_to_mon">
                                <?php
                            $data = get_list_to_mon(); foreach ($data as $row)
                                echo '<option value="' . $row['id'] . '">' . $row['ten_to_mon'] . '</option>'
                                    ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Hủy bỏ">
                        <input type="submit" class="btn btn-info edit_teacher" value="Lưu">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Delete Modal HTML -->
    <div id="deleteViewModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h4 class="modal-title">Xóa giảng viên</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Bạn có chắc chắc muốn xóa </p>
                        <p class="text-warning"><small>Thao tác này không thể hoàn tác.</small></p>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Hủy bỏ">
                        <input type="submit" class="btn btn-danger delete_teacher" value="Delete">
                    </div>
                </form>
            </div>
        </div>
    </div>